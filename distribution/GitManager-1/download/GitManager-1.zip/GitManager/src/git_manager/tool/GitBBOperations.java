package git_manager.tool;

import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GitBBOperations {

	public GitBBOperations() {
		System.out
				.println("Proof-of-concept: Only viewing number of issues in a BitBucket repo has been implemented...");
		viewIssueNumber();
	}

	// TODO: The viewIssueNumber() takes ridiculously long (~15minutes?) to
	// update when a
	// new issue is added, as well as when an issue is
	// deleted, though the JSON data takes no time at all to update in either
	// case. Find
	// out whats wrong when adding an issue on bitbucket.

	public void viewIssueNumber() {
		JTextField accName = new JTextField(15);
		JTextField repoSlug = new JTextField(15);

		String acc = null, repo = null;

		JPanel panel = new JPanel(new GridLayout(0, 1));
		JPanel un = new JPanel();
		JPanel un3 = new JPanel();

		un.add(new JLabel("Owner's Account Name:   "));
		un.add(accName);
		panel.add(un);

		un3.add(new JLabel("Repo Name:"));
		un3.add(repoSlug);
		panel.add(un3);

		int result = JOptionPane.showConfirmDialog(null, panel,
				"View BitBucket repository's issue list",
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
		if (result == JOptionPane.OK_OPTION) {
			acc = accName.getText();
			repo = repoSlug.getText();
		}

		if (acc == null || repo == null) {
			System.out.println("View Issue List Cancelled");
			return;
		}

		if (acc.equals("") || repo.equals("")) {
			if (acc.equals(""))
				System.out.println("Please enter an account name.");
			if (repo.equals(""))
				System.out.println("Please enter an repository name.");
			acc = repo = null;
			return;
		}

		URL url;
		try {
			url = new URL("https://bitbucket.org/api/1.0/repositories/" + acc
					+ "/" + repo + "/issues");

			BufferedReader reader = null;

			try {
				reader = new BufferedReader(new InputStreamReader(
						url.openStream(), "UTF-8"));
				String bitBucketData = "";
				for (String line; (line = reader.readLine()) != null;) {
					System.out.println(line);
					bitBucketData += line;
				}
				// To get the number of issues in the repo

				JsonParser parser = new JsonParser();
				JsonObject obj = parser.parse(bitBucketData).getAsJsonObject();
				int issueNum = obj.get("count").getAsInt();
				System.out.println("There are " + issueNum + " issues in the "
						+ repo + " repository");
				issueNum = 0;
				bitBucketData = null;
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				if (reader != null)
					try {
						reader.close();
					} catch (IOException ignore) {
					}
			}
		} catch (MalformedURLException e1) {
			e1.printStackTrace();
		}
	}

	class IssueData {
		private int count;
		private String filter;
		private String search;
		private List<Issue> issues;
	}

	class Issue {

	}
}

// {"count": 1, "filter": {"priority": [["", "minor"]]}, "search": null,
// "issues": [{"status": "new", "priority": "minor", "title":
// "Test Issue No. 2",
// "reported_by": {"username": "joel_moniz", "first_name": "Joel", "last_name":
// "Moniz",
// "display_name": "Joel Moniz", "is_team": false, "avatar":
// "https://secure.gravatar.com/avatar/b0093fa9da51e42168545e83750c3e81?d=https%3A%2F%2Fd3oaxc4q5k2d6q.cloudfront.net%2Fm%2F48695e7c3140%2Fimg%2Fdefault_avatar%2F32%2Fuser_blue.png&s=32",
// "resource_uri": "/1.0/users/joel_moniz"}, "utc_last_updated":
// "2014-03-21 15:37:33+00:00",
// "responsible": {"username": "joel_moniz", "first_name": "Joel", "last_name":
// "Moniz",
// "display_name": "Joel Moniz", "is_team": false, "avatar":
// "https://secure.gravatar.com/avatar/b0093fa9da51e42168545e83750c3e81?d=https%3A%2F%2Fd3oaxc4q5k2d6q.cloudfront.net%2Fm%2F48695e7c3140%2Fimg%2Fdefault_avatar%2F32%2Fuser_blue.png&s=32",
// "resource_uri": "/1.0/users/joel_moniz"},
// "metadata": {"kind": "enhancement", "version": null, "component": null,
// "milestone": null},
// "content": "Another test issue... Wheee this is fun!", "created_on":
// "2014-03-21T16:37:33.081",
// "local_id": 2, "utc_created_on": "2014-03-21 15:37:33+00:00",
// "resource_uri": "/1.0/repositories/joel_moniz/test/issues/2", "is_spam":
// false}]}
