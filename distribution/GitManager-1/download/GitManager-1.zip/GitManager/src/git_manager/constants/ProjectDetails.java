package git_manager.constants;

public class ProjectDetails {
	public static final String NAME = "GitHub Manager";
	public static final String VERSION = "0.1.0";
}
